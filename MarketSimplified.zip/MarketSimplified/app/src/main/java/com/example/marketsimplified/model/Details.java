package com.example.marketsimplified.model;

import java.util.List;

public class Details {

    private int id;
    private String name;
    List<OwnerDetails> detailsList;

    public Details(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public Details(int id, String name, List<OwnerDetails> detailsList) {
        this.id = id;
        this.name = name;
        this.detailsList = detailsList;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<OwnerDetails> getDetailsList() {
        return detailsList;
    }

    public void setDetailsList(List<OwnerDetails> detailsList) {
        this.detailsList = detailsList;
    }
}
