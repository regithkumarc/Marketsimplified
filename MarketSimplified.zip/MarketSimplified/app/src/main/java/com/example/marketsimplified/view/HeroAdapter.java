package com.example.marketsimplified.view;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.marketsimplified.R;
import com.example.marketsimplified.model.Details;

import java.util.List;

public class HeroAdapter extends RecyclerView.Adapter<HeroAdapter.HeroViewHolder> {

    Context context;
    List<Details> heroList;

    public HeroAdapter(Context context, List<Details> heroList){
       this.context = context;
       this.heroList = heroList;
    }

    @NonNull
    @Override
    public HeroViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.details_list_item,parent,false);
        return new HeroViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HeroViewHolder holder, int position) {

        Details details = heroList.get(position);

        Glide.with(context).load(details.getDetailsList().get(position).getAvatarUrl()).into(holder.imageView);
        holder.owner_id.setText(details.getDetailsList().get(position).getId());
        holder.owner_name.setText(details.getDetailsList().get(position).getLogin());
    }

    @Override
    public int getItemCount() {
        return heroList.size();
    }

    class HeroViewHolder extends RecyclerView.ViewHolder{

        ImageView imageView;
        TextView owner_id,owner_name;

        public HeroViewHolder(View view){
            super(view);

            imageView = view.findViewById(R.id.avatarUrl);
            owner_id = view.findViewById(R.id.owner_id);
            owner_name = view.findViewById(R.id.owner_name);
        }
    }
}

