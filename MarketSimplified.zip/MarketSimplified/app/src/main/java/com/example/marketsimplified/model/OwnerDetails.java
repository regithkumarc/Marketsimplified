package com.example.marketsimplified.model;

public class OwnerDetails {

    private int id;
    private String avatarUrl;
    private String login;
    private String url;

    public OwnerDetails(int id, String avatarUrl, String login, String url) {
        this.id = id;
        this.avatarUrl = avatarUrl;
        this.login = login;
        this.url = url;
    }

    public int getId() {
        return id;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public String getLogin() {
        return login;
    }

    public String getUrl() {
        return url;
    }
}
