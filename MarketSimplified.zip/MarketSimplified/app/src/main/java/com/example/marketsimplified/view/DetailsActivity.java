package com.example.marketsimplified.view;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.marketsimplified.R;
import com.example.marketsimplified.model.Details;
import com.example.marketsimplified.viewmodel.DetailsViewModel;

import java.util.List;

public class DetailsActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    HeroAdapter heroAdapter;
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.details_list);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

       DetailsViewModel detailsViewModel =  ViewModelProviders.of(this).get(DetailsViewModel.class);

        detailsViewModel.getDetails().observe(this, new Observer<List<Details>>() {
           @Override
           public void onChanged(List<Details> heroes) {
               heroAdapter = new HeroAdapter(DetailsActivity.this,heroes);
               recyclerView.setAdapter(heroAdapter);
           }
       });
    }
}
